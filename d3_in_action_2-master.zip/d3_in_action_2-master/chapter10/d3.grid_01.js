d3.gridLayout = () => {
  function processGrid(data) {
    console.log(data);
  }
  return processGrid;
};
